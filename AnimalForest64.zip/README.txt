-e Animal Forest 64 - Recompiled Port (RT64 Engine)

Controles:
X = A | C = B | ENTER = Start | Setas = D-Pad
